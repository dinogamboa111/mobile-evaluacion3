package duoc.desarrollomobile.sitioejemplo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.rememberNavController
import duoc.desarrollomobile.sitioejemplo.data.AppDatabase
import duoc.desarrollomobile.sitioejemplo.model.MisionRepository
import duoc.desarrollomobile.sitioejemplo.model.PlanetaRepository
import duoc.desarrollomobile.sitioejemplo.navigation.AppNavigation
import duoc.desarrollomobile.sitioejemplo.ui.theme.SitioEjemploTheme
import duoc.desarrollomobile.sitioejemplo.utils.NotificationHelper
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import duoc.desarrollomobile.sitioejemplo.viewmodel.PlanetaViewModel

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.createNotificationChannel(this)
        requestNotificationPermission()

        // ===== INICIALIZAR BASE DE DATOS =====
        val database = AppDatabase.getDatabase(applicationContext)

        // ===== CREAR API SERVICE =====
        val apiService = duoc.desarrollomobile.sitioejemplo.api.ApiClient.apiService

        // ===== CREAR REPOSITORIES CON LOS DAOs =====
        val planetaRepository = PlanetaRepository(database.planetaDao())
        val misionRepository = MisionRepository(
            database.misionDao(),
            duoc.desarrollomobile.sitioejemplo.api.ApiClient.misionApiService
        )

        // ===== CREAR VIEWMODELS =====
        val planetaViewModel = PlanetaViewModel(planetaRepository)
        val misionViewModel = MisionViewModel(misionRepository, planetaRepository)

        setContent {
            SitioEjemploTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppNavigation(
                        navController = navController,
                        misionViewModel = misionViewModel,
                        planetaViewModel = planetaViewModel
                    )
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {}
                else -> requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
