package duoc.desarrollomobile.sitioejemplo.api

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit

object ApiClient {

    private const val BASE_URL = "http://10.0.2.2:8080/"

    // Tipo de contenido para JSON
    private val contentType = "application/json".toMediaType()

    // Configuración de Kotlinx Serialization
    private val json = Json {
        ignoreUnknownKeys = true // Ignora campos extras del JSON
        isLenient = true         // Permite formatos no estrictos
    }

    // Retrofit Builder
    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }

    // Servicios API listos para usar
    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java) // para planetas
    }

    val misionApiService: MisionApiService by lazy {
        retrofit.create(MisionApiService::class.java) // para misiones
    }
}
