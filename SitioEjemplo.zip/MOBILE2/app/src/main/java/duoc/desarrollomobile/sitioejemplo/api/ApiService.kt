package duoc.desarrollomobile.sitioejemplo.api

import duoc.desarrollomobile.sitioejemplo.data.Planeta
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {

    // ===== PLANETAS =====
    @GET("/api/planetas")
    suspend fun getPlanetas(): List<Planeta>

    @GET("/api/planetas/{id}")
    suspend fun getPlanetaById(@Path("id") id: Int): Planeta

}
