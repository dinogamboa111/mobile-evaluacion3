package duoc.desarrollomobile.sitioejemplo.api

import duoc.desarrollomobile.sitioejemplo.data.Mision
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Locale


@Serializable
data class MisionApiDTO(
    val id: Int = 0,
    val nombreMision: String,
    val objetivo: String,
    val planeta: String,
    val fechaLanzamiento: String,  // "2025-12-10" desde API
    val horaLanzamiento: String,
    val nivelUrgencia: String,
    val completada: Boolean = false,
    val notificacionActiva: Boolean = true,
    val isFavorita: Boolean = false
) {

    fun toMision(): Mision {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timestamp = try {
            dateFormat.parse(fechaLanzamiento)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }

        return Mision(
            id = id,
            nombreMision = nombreMision,
            objetivo = objetivo,
            planeta = planeta,
            fechaLanzamiento = timestamp,
            horaLanzamiento = horaLanzamiento,
            nivelUrgencia = nivelUrgencia,
            completada = completada,
            notificacionActiva = notificacionActiva,
            isFavorita = isFavorita
        )
    }
}