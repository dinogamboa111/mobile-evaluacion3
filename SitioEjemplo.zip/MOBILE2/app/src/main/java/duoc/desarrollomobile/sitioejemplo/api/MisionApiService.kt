package duoc.desarrollomobile.sitioejemplo.api

import okhttp3.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface MisionApiService {

    @GET("api/misiones")
    suspend fun getAllMisiones(): List<MisionApiDTO>


    @POST("api/misiones")
    suspend fun crearMision(@Body mision: MisionApiDTO): MisionApiDTO

    @PUT("api/misiones/{id}")
    suspend fun actualizarMision(
        @Path("id") id: Int,
        @Body mision: MisionApiDTO
    ): MisionApiDTO

    @DELETE("api/misiones/{id}")
    suspend fun deleteMision(@Path("id") id: Int)
}
