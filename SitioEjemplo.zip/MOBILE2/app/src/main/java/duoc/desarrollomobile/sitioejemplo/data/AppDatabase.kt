package duoc.desarrollomobile.sitioejemplo.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Base de datos principal de la aplicación usando Room
 * Incluye las tablas: Mision y Planeta
 */
@Database(
    entities = [Mision::class, Planeta::class],
    version = 5,  // ← Incrementado de 4 a 5
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun misionDao(): MisionDao
    abstract fun planetaDao(): PlanetaDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mision_database"
                )
                    // En desarrollo: destruye y recrea la BD si hay cambios de schema
                    // En producción deberías usar migrations
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}