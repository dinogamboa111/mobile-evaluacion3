package duoc.desarrollomobile.sitioejemplo.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "misiones")
data class Mision(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nombreMision: String,
    val objetivo: String,
    val planeta: String,
    val fechaLanzamiento: Long,
    val horaLanzamiento: String,
    val nivelUrgencia: String,
    val completada: Boolean = false,
    val notificacionActiva: Boolean = true,
    val isFavorita: Boolean = false
)