package duoc.desarrollomobile.sitioejemplo.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MisionDao {

    @Query("SELECT * FROM misiones ORDER BY fechaLanzamiento ASC")
    fun getAllMisiones(): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE completada = 0 ORDER BY fechaLanzamiento ASC")
    fun getMisionesPendientes(): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE completada = 1 ORDER BY fechaLanzamiento DESC")
    fun getMisionesCompletadas(): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE isFavorita = 1 ORDER BY fechaLanzamiento ASC")
    fun getMisionesFavoritas(): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE isFavorita = 1 AND completada = 0 ORDER BY fechaLanzamiento ASC")
    fun getMisionesFavoritasPendientes(): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE completada = 0 ORDER BY fechaLanzamiento ASC LIMIT :limite")
    fun getProximasMisiones(limite: Int): Flow<List<Mision>>

    @Query("SELECT * FROM misiones WHERE id = :misionId")
    suspend fun getMisionById(misionId: Int): Mision?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mision: Mision)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(misiones: List<Mision>) // <-- Esto es lo que faltaba

    @Update
    suspend fun update(mision: Mision)

    @Delete
    suspend fun delete(mision: Mision)

    @Query("UPDATE misiones SET completada = NOT completada WHERE id = :misionId")
    suspend fun toggleCompletada(misionId: Int)

    @Query("DELETE FROM misiones WHERE completada = 1")
    suspend fun deleteAllCompletadas()

    @Query("SELECT COUNT(*) FROM misiones")
    suspend fun getTotalMisiones(): Int

    @Query("SELECT COUNT(*) FROM misiones WHERE completada = 0")
    suspend fun getTotalPendientes(): Int

    @Query("SELECT COUNT(*) FROM misiones WHERE completada = 1")
    suspend fun getTotalCompletadas(): Int

    @Query("SELECT COUNT(*) FROM misiones WHERE isFavorita = 1")
    suspend fun getTotalFavoritas(): Int
}
