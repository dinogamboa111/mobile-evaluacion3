package duoc.desarrollomobile.sitioejemplo.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Entity de Room que representa la tabla de planetas en SQLite
 * Esta entidad almacena información sobre los planetas del sistema solar
 * para categorizar las misiones espaciales
 *
 * @Entity indica que esta clase es una tabla de Room
 * tableName define el nombre de la tabla en la base de datos
 */
@Serializable
@Entity(tableName = "planetas")
data class Planeta(
    /**
     * @PrimaryKey indica que este campo es la clave primaria
     * autoGenerate = true hace que Room genere automáticamente un ID único
     */
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    /**
     * Nombre del planeta (ej: "Marte", "Júpiter")
     * Campo obligatorio
     */
    val nombre: String,

    /**
     * Descripción detallada del planeta
     * Información científica o curiosidades
     */
    val descripcion: String?,

    /**
     * Distancia promedio al Sol en millones de kilómetros
     * Para ordenar planetas por distancia o mostrar datos
     */
    val distanciaSol: Double,

    /**
     * Tipo de planeta o cuerpo celeste
     * Valores: "Rocoso", "Gaseoso", "Enano", "Satélite", "Sistema"
     */
    val tipo: String,

    /**
     * Color representativo del planeta en formato hexadecimal
     * Se usa para tematizar la UI (ej: "#CD5C5C" para Marte)
     */
    val colorHex: String?,

    /**
     * Nombre de la imagen o recurso drawable del planeta
     * Para mostrar íconos o imágenes en la interfaz
     */
    val imagen: String?
)