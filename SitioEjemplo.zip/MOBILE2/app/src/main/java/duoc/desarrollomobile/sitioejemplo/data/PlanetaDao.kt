package duoc.desarrollomobile.sitioejemplo.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlanetaDao {

    @Query("SELECT * FROM planetas ORDER BY distanciaSol ASC")
    fun getAllPlanetas(): Flow<List<Planeta>>

    @Query("SELECT * FROM planetas WHERE id = :planetaId")
    suspend fun getPlanetaById(planetaId: Int): Planeta?

    @Query("SELECT * FROM planetas WHERE tipo = :tipo ORDER BY distanciaSol ASC")
    fun getPlanetasPorTipo(tipo: String): Flow<List<Planeta>>

    @Query("SELECT * FROM planetas ORDER BY distanciaSol ASC")
    suspend fun getPlanetasSync(): List<Planeta>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(planeta: Planeta)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(planetas: List<Planeta>)

    @Update
    suspend fun update(planeta: Planeta)

    @Delete
    suspend fun delete(planeta: Planeta)

    @Query("DELETE FROM planetas")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM planetas")
    suspend fun getCount(): Int
}