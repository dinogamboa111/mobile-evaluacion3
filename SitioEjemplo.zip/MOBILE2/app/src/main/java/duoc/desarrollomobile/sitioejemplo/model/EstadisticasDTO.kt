package duoc.desarrollomobile.sitioejemplo.model

data class EstadisticasDTO(
    val totalMisiones: Int,
    val pendientes: Int,
    val completadas: Int,
    val favoritas: Int
)
