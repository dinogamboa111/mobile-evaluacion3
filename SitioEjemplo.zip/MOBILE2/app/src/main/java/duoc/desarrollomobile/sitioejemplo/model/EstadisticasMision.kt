package duoc.desarrollomobile.sitioejemplo.model

data class EstadisticasMision(
    val total: Int,
    val pendientes: Int,
    val completadas: Int,
    val favoritas: Int
)