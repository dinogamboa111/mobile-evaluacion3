package duoc.desarrollomobile.sitioejemplo.model


enum class FiltroMision {
    PENDIENTES,
    COMPLETADAS,
    FAVORITAS,
    TODAS
}
