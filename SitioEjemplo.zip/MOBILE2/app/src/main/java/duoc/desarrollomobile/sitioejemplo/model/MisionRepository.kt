package duoc.desarrollomobile.sitioejemplo.model

import duoc.desarrollomobile.sitioejemplo.api.MisionApiDTO
import duoc.desarrollomobile.sitioejemplo.api.MisionApiService
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.data.MisionDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import android.util.Log
import java.util.Locale

class MisionRepository(
    private val misionDao: MisionDao,
    private val api: MisionApiService
) {

    // --- Flows desde Room ---
    val allMisiones: Flow<List<Mision>> = misionDao.getAllMisiones()
    val misionesPendientes: Flow<List<Mision>> = misionDao.getMisionesPendientes()
    val misionesCompletadas: Flow<List<Mision>> = misionDao.getMisionesCompletadas()
    val misionesFavoritas: Flow<List<Mision>> = misionDao.getMisionesFavoritas()
    val misionesFavoritasPendientes: Flow<List<Mision>> = misionDao.getMisionesFavoritasPendientes()

    // --- Operaciones básicas de Room ---
    suspend fun insertMision(mision: Mision) {
        misionDao.insertAll(listOf(mision))
    }


    suspend fun insertMisiones(misiones: List<Mision>) {
        withContext(Dispatchers.IO) { misionDao.insertAll(misiones) }
    }

    suspend fun updateMision(mision: Mision) {
        withContext(Dispatchers.IO) { misionDao.update(mision) }
    }

    suspend fun deleteMision(mision: Mision) {
        withContext(Dispatchers.IO) {
            try {
                // Borra en API
                api.deleteMision(mision.id)

                // Borra en Room
                misionDao.delete(mision)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    suspend fun updateCompletada(misionId: Int) {
        withContext(Dispatchers.IO) { misionDao.toggleCompletada(misionId) }
    }

    suspend fun deleteAllCompletadas() {
        withContext(Dispatchers.IO) { misionDao.deleteAllCompletadas() }
    }

    fun getProximasMisiones(limite: Int = 5): Flow<List<Mision>> {
        return misionDao.getProximasMisiones(limite)
    }

    suspend fun crearMisionEnApi(mision: Mision): Mision? {
        return try {
            val misionDto = MisionApiDTO(
                id = 0,
                nombreMision = mision.nombreMision,
                objetivo = mision.objetivo,
                planeta = mision.planeta,
                fechaLanzamiento = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(mision.fechaLanzamiento)),
                horaLanzamiento = mision.horaLanzamiento,
                nivelUrgencia = mision.nivelUrgencia,
                completada = mision.completada,
                notificacionActiva = mision.notificacionActiva,
                isFavorita = mision.isFavorita
            )
            val respuestaApi = api.crearMision(misionDto) // Llamada Retrofit POST
            val nuevaMisionRoom = respuestaApi.toMision()
            insertMision(nuevaMisionRoom) // Actualiza Room con la misión real del backend
            nuevaMisionRoom
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    suspend fun getEstadisticas(): EstadisticasDTO {
        return withContext(Dispatchers.IO) {
            val total = misionDao.getTotalMisiones()
            val pendientes = misionDao.getTotalPendientes()
            val completadas = misionDao.getTotalCompletadas()
            val favoritas = misionDao.getTotalFavoritas()
            EstadisticasDTO(totalMisiones = total, pendientes = pendientes, completadas = completadas, favoritas = favoritas)
        }
    }

    suspend fun getMisionById(id: Int): Mision? {
        return withContext(Dispatchers.IO) { misionDao.getMisionById(id) }
    }

    // --- NUEVO: Sincronización desde API ---
    suspend fun syncMisionesDesdeApi() {
        withContext(Dispatchers.IO) {
            try {
                Log.d("MisionRepo", "⏳ Iniciando sincronización desde API...")

                val apiMisiones: List<MisionApiDTO> = api.getAllMisiones() // ahora OK
                Log.d("MisionRepo", "✅ Misiones recibidas desde API: ${apiMisiones.size}")
                apiMisiones.forEach { Log.d("MisionRepo", it.toString()) }

                val misionesRoom: List<Mision> = apiMisiones.map { it.toMision() }
                misionDao.insertAll(misionesRoom)
                Log.d("MisionRepo", "✅ Misiones sincronizadas en Room")
            } catch (e: retrofit2.HttpException) {
                Log.e("MisionRepo", "❌ HTTP error: ${e.code()} - ${e.message()}", e)
            } catch (e: Exception) {
                Log.e("MisionRepo", "❌ Error general al sincronizar misiones desde API", e)
            }
        }
    }

    // --- Actualizar completada (PUT) ---
    suspend fun toggleCompletadaMision(mision: Mision): Mision? {
        return try {
            // Cambia el estado completada
            val actualizado = mision.copy(completada = !mision.completada)

            // Llama PUT al backend
            val respuestaApi = api.actualizarMision(actualizado.id, MisionApiDTO(
                id = actualizado.id,
                nombreMision = actualizado.nombreMision,
                objetivo = actualizado.objetivo,
                planeta = actualizado.planeta,
                fechaLanzamiento = SimpleDateFormat("yyyy-MM-dd").format(Date(actualizado.fechaLanzamiento)),
                horaLanzamiento = actualizado.horaLanzamiento,
                nivelUrgencia = actualizado.nivelUrgencia,
                completada = actualizado.completada,
                notificacionActiva = actualizado.notificacionActiva,
                isFavorita = actualizado.isFavorita
            ))

            val misionActualizada = respuestaApi.toMision()
            misionDao.update(misionActualizada) // Actualiza Room
            misionActualizada
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }








}
