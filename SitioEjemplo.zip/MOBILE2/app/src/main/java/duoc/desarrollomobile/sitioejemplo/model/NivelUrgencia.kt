package duoc.desarrollomobile.sitioejemplo.model

enum class NivelUrgencia(val displayName: String, val emoji: String, val colorValue: Long) {
    CRITICA("Crítica", "🚨", 0xFFFF4444),
    ALTA("Alta", "⚡", 0xFFFF8800),
    MEDIA("Media", "🌟", 0xFFFFBB33),
    BAJA("Baja", "💫", 0xFF00C851),
    RUTINA("Rutina", "🛸", 0xFF33B5E5);

    companion object {
        fun fromString(value: String): NivelUrgencia {
            return entries.find { it.name == value } ?: RUTINA
        }

        fun getAllDisplayNames(): List<String> {
            return entries.map { it.displayName }
        }

        fun getAllDisplayNamesWithEmoji(): List<String> {
            return entries.map { "${it.emoji} ${it.displayName}" }
        }

        fun getOrdenadosPorCriticidad(): List<NivelUrgencia> {
            return listOf(CRITICA, ALTA, MEDIA, BAJA, RUTINA)
        }

        fun getNivelesUrgentes(): List<NivelUrgencia> {
            return entries.filter { it != RUTINA }
        }
    }
}
