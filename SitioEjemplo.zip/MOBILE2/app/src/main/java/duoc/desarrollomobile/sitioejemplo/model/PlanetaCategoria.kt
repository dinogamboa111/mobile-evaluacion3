package duoc.desarrollomobile.sitioejemplo.model

enum class PlanetaCategoria(val displayName: String, val emoji: String) {
    MERCURIO("Mercurio", "☿️"),
    VENUS("Venus", "♀️"),
    TIERRA("Tierra", "🌍"),
    MARTE("Marte", "♂️"),
    JUPITER("Júpiter", "♃"),
    SATURNO("Saturno", "♄"),
    URANO("Urano", "♅"),
    NEPTUNO("Neptuno", "♆"),
    LUNA("Luna", "🌙"),
    SISTEMA_SOLAR("Sistema Solar", "🌌");

    companion object {
        fun fromString(value: String): PlanetaCategoria {
            return entries.find { it.name == value } ?: SISTEMA_SOLAR
        }

        fun getAllDisplayNames(): List<String> {
            return entries.map { it.displayName }
        }

        fun getAllDisplayNamesWithEmoji(): List<String> {
            return entries.map { "${it.emoji} ${it.displayName}" }
        }

        fun getPlanetasPrincipales(): List<PlanetaCategoria> {
            return entries.filter { it != LUNA && it != SISTEMA_SOLAR }
        }
    }
}


