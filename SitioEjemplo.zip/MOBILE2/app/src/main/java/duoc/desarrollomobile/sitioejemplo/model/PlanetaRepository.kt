package duoc.desarrollomobile.sitioejemplo.model

import android.util.Log
import duoc.desarrollomobile.sitioejemplo.api.ApiClient
import duoc.desarrollomobile.sitioejemplo.data.Planeta
import duoc.desarrollomobile.sitioejemplo.data.PlanetaDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlanetaRepository(private val planetaDao: PlanetaDao) {

    private val api = ApiClient.apiService

    // Exponemos los planetas desde Room como Flow
    val allPlanetas: Flow<List<Planeta>> = planetaDao.getAllPlanetas()

    /**
     * Precarga planetas desde la API y los guarda en Room
     * Solo descarga si la BD está vacía
     */
    suspend fun precargarPlanetasIniciales() {
        withContext(Dispatchers.IO) {
            try {
                Log.d("PlanetaRepo", "🚀 Iniciando precarga de planetas...")

                // Verificar si ya hay planetas en la BD
                val planetasExistentes = planetaDao.getPlanetasSync()
                Log.d("PlanetaRepo", "📊 Planetas en BD: ${planetasExistentes.size}")

                if (planetasExistentes.isEmpty()) {
                    Log.d("PlanetaRepo", "🌐 BD vacía, descargando desde API...")

                    // Descargar desde la API
                    val planetasApi = api.getPlanetas()
                    Log.d("PlanetaRepo", "✅ Descargados ${planetasApi.size} planetas de la API")

                    // Guardar en Room
                    planetaDao.insertAll(planetasApi)
                    Log.d("PlanetaRepo", "💾 Planetas guardados en Room")
                } else {
                    Log.d("PlanetaRepo", "✅ Planetas ya existen en BD, no es necesario descargar")
                }
            } catch (e: Exception) {
                Log.e("PlanetaRepo", "❌ Error al precargar planetas: ${e.message}", e)
                e.printStackTrace()
            }
        }
    }

    /**
     * Fuerza la recarga de planetas desde la API
     * Útil si necesitas actualizar los datos
     */
    suspend fun recargarPlanetasDesdeApi() {
        withContext(Dispatchers.IO) {
            try {
                val planetasApi = api.getPlanetas()
                planetaDao.deleteAll()
                planetaDao.insertAll(planetasApi)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Obtiene un planeta por ID desde Room
     * Si no existe, intenta descargarlo de la API
     */
    suspend fun getPlanetaById(id: Int): Planeta? {
        return withContext(Dispatchers.IO) {
            try {
                // Primero intentar desde Room
                var planeta = planetaDao.getPlanetaById(id)

                // Si no existe, intentar desde API
                if (planeta == null) {
                    planeta = api.getPlanetaById(id)
                    // Guardar en Room para futuras consultas
                    planeta?.let { planetaDao.insert(it) }
                }

                planeta
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    /**
     * Obtiene planetas por tipo
     */
    fun getPlanetasPorTipo(tipo: String): Flow<List<Planeta>> {
        return planetaDao.getPlanetasPorTipo(tipo)
    }
}