package duoc.desarrollomobile.sitioejemplo.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import duoc.desarrollomobile.sitioejemplo.view.*
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import duoc.desarrollomobile.sitioejemplo.viewmodel.PlanetaViewModel

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Form : Screen("form")
    object Detail : Screen("detail/{misionId}") {
        fun createRoute(misionId: Int) = "detail/$misionId"
    }
    object MisionList : Screen("mision_list/{filtro}") {
        fun createRoute(filtro: FiltroMision) = "mision_list/${filtro.name}"
    }
    object Planetas : Screen("planetas")
    object PlanetaDetail : Screen("planeta_detail/{planetaId}") {
        fun createRoute(planetaId: Int) = "planeta_detail/$planetaId"
    }
    object CentroControl : Screen("centro_control")
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    misionViewModel: MisionViewModel,
    planetaViewModel: PlanetaViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = misionViewModel,
                onNavigateToForm = { navController.navigate(Screen.Form.route) },
                onNavigateToList = { filtro ->
                    navController.navigate(Screen.MisionList.createRoute(filtro))
                },
                onNavigateToDetail = { misionId ->
                    navController.navigate(Screen.Detail.createRoute(misionId))
                },
                onNavigateToPlanetas = { navController.navigate(Screen.Planetas.route) },
                onNavigateToCentroControl = { navController.navigate(Screen.CentroControl.route) }
            )
        }

        composable(
            route = Screen.MisionList.route,
            arguments = listOf(navArgument("filtro") { type = NavType.StringType })
        ) { backStackEntry ->
            val filtroString = backStackEntry.arguments?.getString("filtro")
            val filtro = try {
                FiltroMision.valueOf(filtroString ?: FiltroMision.PENDIENTES.name)
            } catch (e: IllegalArgumentException) {
                FiltroMision.PENDIENTES
            }

            MisionListScreen(
                viewModel = misionViewModel,
                filtroInicial = filtro,
                onNavigateToDetail = { misionId ->
                    navController.navigate(Screen.Detail.createRoute(misionId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Form.route) {
            FormScreen(
                viewModel = misionViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Detail.route,
            arguments = listOf(navArgument("misionId") { type = NavType.IntType })
        ) { backStackEntry ->
            val misionId = backStackEntry.arguments?.getInt("misionId") ?: 0
            DetailScreen(
                misionId = misionId,
                viewModel = misionViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Planetas.route) {
            PlanetasScreen(
                viewModel = planetaViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToPlanetaDetail = { planetaId ->
                    navController.navigate(Screen.PlanetaDetail.createRoute(planetaId))
                }
            )
        }

        composable(
            route = Screen.PlanetaDetail.route,
            arguments = listOf(navArgument("planetaId") { type = NavType.IntType })
        ) { backStackEntry ->
            val planetaId = backStackEntry.arguments?.getInt("planetaId") ?: 0
            PlanetaDetailScreen(
                planetaId = planetaId,
                viewModel = planetaViewModel,
                misionViewModel = misionViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMision = { misionId ->
                    navController.navigate(Screen.Detail.createRoute(misionId))
                }
            )
        }

        composable(Screen.CentroControl.route) {
            CentroControlScreen(
                viewModel = misionViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMision = { misionId ->
                    navController.navigate(Screen.Detail.createRoute(misionId))
                }
            )
        }
    }
}
