package duoc.desarrollomobile.sitioejemplo.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource

// Asegúrate de que tu R package sea accesible
import duoc.desarrollomobile.sitioejemplo.R


object AppThemeExtensions {

    // Colores para el efecto galáctico - MODO OSCURO
    private val DeepSpace = Color(0xFF0F0825)           // Negro-morado muy oscuro
    private val DarkPurple = Color(0xFF1E1140)          // Morado oscuro intermedio

    // Colores para el efecto galáctico - MODO CLARO
    private val LightSpacePurple = Color(0xFF4A148C)    // Morado espacial para modo claro
    private val LightSpaceBlue = Color(0xFF0F0825)      // Azul-morado para modo claro
    private val SoftPurple = Color(0xFF1E1140)          // Morado suave

    /**
     * Propiedad original Brush (se mantiene para compatibilidad, pero ya no se usa)
     */
    val deepSpaceBrush: Brush
        @Composable
        get() {
            // MISMO fondo para ambos modos - siempre oscuro y espacial
            return Brush.radialGradient(
                colors = listOf(
                    DeepSpace,      // Negro-morado muy oscuro en el centro
                    DarkPurple,     // Morado oscuro intermedio
                    Color(0xFF1A0F2E) // Morado oscuro en los bordes
                ),
                radius = 1200f
            )
        }

    // 🌌 NUEVO COMPONENTE: Dibuja la imagen de fondo estática
    // Este se usará en lugar de .background(deepSpaceBrush)
    @Composable
    fun DeepSpaceBackground(modifier: Modifier = Modifier) {
        Image(
            //  REEMPLAZAR CON EL NOMBRE DE TU RECURSO
            painter = painterResource(id = R.drawable.ic_fondo_galaxia),
            contentDescription = null, // No necesita descripción si es solo decorativo
            contentScale = ContentScale.Crop, // Asegura que la imagen cubra todo el espacio
            modifier = modifier.fillMaxSize()
        )
    }
}