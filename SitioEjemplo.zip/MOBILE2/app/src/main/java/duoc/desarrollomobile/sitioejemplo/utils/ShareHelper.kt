package duoc.desarrollomobile.sitioejemplo.utils

import android.content.Context
import android.content.Intent
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.model.PlanetaCategoria
import duoc.desarrollomobile.sitioejemplo.model.NivelUrgencia
import java.text.SimpleDateFormat
import java.util.*

/**
 * Helper para compartir misiones espaciales usando el Intent de Android
 * Permite compartir misiones a través de WhatsApp, Email, SMS, etc.
 */
object ShareHelper {

    /**
     * Comparte una misión usando el Intent.ACTION_SEND de Android
     * El usuario podrá elegir qué aplicación usar para compartir
     *
     * @param context Contexto de Android
     * @param mision Misión a compartir
     */
    fun compartirMision(context: Context, mision: Mision) {
        val planeta = PlanetaCategoria.fromString(mision.planeta)
        val nivelUrgencia = NivelUrgencia.fromString(mision.nivelUrgencia)

        // Formatear la fecha
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val fechaFormateada = dateFormat.format(Date(mision.fechaLanzamiento))

        // Crear el texto a compartir
        val textoCompartir = buildString {
            appendLine("🚀 MISIÓN ESPACIAL - GALAXY TASKS")
            appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLine()
            appendLine("🛸 Nombre de la Misión:")
            appendLine(mision.nombreMision)
            appendLine()
            appendLine("🎯 Objetivo:")
            appendLine(mision.objetivo)
            appendLine()
            appendLine("${planeta.emoji} Planeta: ${planeta.displayName}")
            appendLine("${nivelUrgencia.emoji} Urgencia: ${nivelUrgencia.displayName}")
            appendLine()
            appendLine("📅 Fecha de lanzamiento: $fechaFormateada")
            appendLine("⏰ Hora: ${mision.horaLanzamiento}")
            appendLine()
            if (mision.isFavorita) {
                appendLine("⭐ Misión destacada")
            }
            if (mision.notificacionActiva) {
                appendLine("🔔 Alerta de lanzamiento activada")
            } else {
                appendLine("🔕 Alerta de lanzamiento desactivada")
            }
            if (mision.completada) {
                appendLine()
                appendLine("✅ Estado: MISIÓN COMPLETADA")
            }
            appendLine()
            appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLine("Compartido desde Galaxy Tasks 🌌")
        }

        // Crear el Intent de compartir
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, textoCompartir)
            type = "text/plain"
        }

        // Crear el chooser para que el usuario elija la app
        val shareIntent = Intent.createChooser(sendIntent, "Compartir misión")

        // Iniciar la actividad
        context.startActivity(shareIntent)
    }

    /**
     * Comparte múltiples misiones a la vez
     * Útil para compartir una lista de misiones pendientes
     *
     * @param context Contexto de Android
     * @param misiones Lista de misiones a compartir
     */
    fun compartirListaMisiones(context: Context, misiones: List<Mision>) {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

        val textoCompartir = buildString {
            appendLine("🚀 PLAN DE MISIONES - GALAXY TASKS")
            appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLine()

            misiones.forEachIndexed { index, mision ->
                val planeta = PlanetaCategoria.fromString(mision.planeta)
                val urgencia = NivelUrgencia.fromString(mision.nivelUrgencia)
                val fechaFormateada = dateFormat.format(Date(mision.fechaLanzamiento))

                appendLine("${index + 1}. ${mision.nombreMision}")
                append("   ${planeta.emoji} ${planeta.displayName}")
                append(" • ${urgencia.emoji}")
                append(" • $fechaFormateada")
                appendLine(" • ${mision.horaLanzamiento}")
                if (mision.isFavorita) {
                    appendLine("   ⭐ Destacada")
                }
                if (mision.completada) {
                    appendLine("   ✅ Completada")
                }
                appendLine()
            }

            appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            val completadas = misiones.count { it.completada }
            val pendientes = misiones.size - completadas
            appendLine("Total: ${misiones.size} misiones")
            appendLine("En curso: $pendientes • Completadas: $completadas")
            appendLine("Compartido desde Galaxy Tasks 🌌")
        }

        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, textoCompartir)
            type = "text/plain"
        }

        val shareIntent = Intent.createChooser(sendIntent, "Compartir plan de misiones")
        context.startActivity(shareIntent)
    }

    /**
     * Alias para mantener compatibilidad con código antiguo
     * @deprecated Usar compartirMision() en su lugar
     */
    @Deprecated("Usar compartirMision() en su lugar", ReplaceWith("compartirMision(context, mision)"))
    fun compartirRecordatorio(context: Context, mision: Mision) {
        compartirMision(context, mision)
    }
}