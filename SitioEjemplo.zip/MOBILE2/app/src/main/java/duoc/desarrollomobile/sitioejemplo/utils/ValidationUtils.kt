package duoc.desarrollomobile.sitioejemplo.utils

/**
 * Object que contiene funciones de validación para el formulario de misiones espaciales
 *
 * object crea un Singleton automáticamente
 * Esto permite usar las funciones sin crear instancias:
 * ValidationUtils.isValidNombreMision("Calibrar Satélite")
 */
object ValidationUtils {

    /**
     * Valida que el nombre de la misión sea válido
     * Requisitos: no vacío, mínimo 3 caracteres, máximo 50 caracteres
     *
     * @param nombreMision Nombre de la misión a validar
     * @return true si el nombre es válido, false si no
     */
    fun isValidNombreMision(nombreMision: String): Boolean {
        // Verificar que no esté vacío
        if (nombreMision.isBlank()) return false

        // Verificar longitud
        if (nombreMision.length < 3 || nombreMision.length > 50) return false

        return true
    }

    /**
     * Valida que el objetivo de la misión sea válido
     * Requisitos: no vacío, mínimo 10 caracteres, máximo 200 caracteres
     *
     * @param objetivo Objetivo a validar
     * @return true si el objetivo es válido, false si no
     */
    fun isValidObjetivo(objetivo: String): Boolean {
        // Verificar que no esté vacío
        if (objetivo.isBlank()) return false

        // Verificar longitud
        if (objetivo.length < 10 || objetivo.length > 200) return false

        return true
    }

    /**
     * Valida que la hora tenga formato válido (HH:mm)
     * Ejemplos válidos: "14:30", "09:00", "23:59"
     * Ejemplos inválidos: "25:00", "14:70", "14", "14:3"
     *
     * @param hora Hora a validar
     * @return true si la hora es válida, false si no
     */
    fun isValidHora(hora: String): Boolean {
        if (hora.isBlank()) return false

        /**
         * Regex para validar hora en formato HH:mm:
         * ^              = Inicio
         * ([01][0-9]|2[0-3])  = Horas: 00-19 o 20-23
         * :              = Dos puntos literal
         * [0-5][0-9]     = Minutos: 00-59
         * $              = Fin
         *
         * Válidos: "00:00", "14:30", "23:59"
         * Inválidos: "24:00", "14:60", "5:30"
         */
        val horaRegex = "^([01][0-9]|2[0-3]):[0-5][0-9]$".toRegex()
        return horaRegex.matches(hora)
    }

    /**
     * Valida que la fecha de lanzamiento sea futura (no puede ser en el pasado)
     *
     * @param fechaLanzamientoMillis Fecha de lanzamiento en milisegundos
     * @return true si la fecha es futura, false si es pasada
     */
    fun isValidFechaLanzamiento(fechaLanzamientoMillis: Long): Boolean {
        // La fecha debe ser mayor o igual que la fecha actual (permitimos hoy)
        return fechaLanzamientoMillis >= System.currentTimeMillis() - 86400000 // -1 día de margen
    }

    /**
     * Valida que el planeta no esté vacío
     *
     * @param planeta Planeta a validar
     * @return true si el planeta es válido, false si no
     */
    fun isValidPlaneta(planeta: String): Boolean {
        return planeta.isNotBlank()
    }

    /**
     * Valida que el nivel de urgencia no esté vacío
     *
     * @param nivelUrgencia Nivel de urgencia a validar
     * @return true si el nivel de urgencia es válido, false si no
     */
    fun isValidNivelUrgencia(nivelUrgencia: String): Boolean {
        return nivelUrgencia.isNotBlank()
    }

    // ========================================
    // MENSAJES DE ERROR
    // ========================================

    /**
     * Obtiene el mensaje de error para el campo nombre de misión
     * @param nombreMision Nombre de misión a validar
     * @return Mensaje de error o null si es válido
     */
    fun getNombreMisionErrorMessage(nombreMision: String): String? {
        return when {
            nombreMision.isBlank() -> "El nombre de la misión es requerido"
            nombreMision.length < 3 -> "El nombre debe tener al menos 3 caracteres"
            nombreMision.length > 50 -> "El nombre no puede exceder 50 caracteres"
            else -> null
        }
    }

    /**
     * Obtiene el mensaje de error para el campo objetivo
     * @param objetivo Objetivo a validar
     * @return Mensaje de error o null si es válido
     */
    fun getObjetivoErrorMessage(objetivo: String): String? {
        return when {
            objetivo.isBlank() -> "El objetivo de la misión es requerido"
            objetivo.length < 10 -> "El objetivo debe tener al menos 10 caracteres"
            objetivo.length > 200 -> "El objetivo no puede exceder 200 caracteres"
            else -> null
        }
    }

    /**
     * Obtiene el mensaje de error para el campo hora
     * @param hora Hora a validar
     * @return Mensaje de error o null si es válida
     */
    fun getHoraErrorMessage(hora: String): String? {
        return when {
            hora.isBlank() -> "La hora de lanzamiento es requerida"
            !isValidHora(hora) -> "Formato de hora inválido. Use HH:mm (ej: 14:30)"
            else -> null
        }
    }

    /**
     * Obtiene el mensaje de error para el campo fecha de lanzamiento
     * @param fechaLanzamientoMillis Fecha de lanzamiento en milisegundos
     * @return Mensaje de error o null si es válida
     */
    fun getFechaLanzamientoErrorMessage(fechaLanzamientoMillis: Long?): String? {
        return when {
            fechaLanzamientoMillis == null -> "La fecha de lanzamiento es requerida"
            !isValidFechaLanzamiento(fechaLanzamientoMillis) -> "La fecha de lanzamiento debe ser futura"
            else -> null
        }
    }

    /**
     * Obtiene el mensaje de error para el campo planeta
     * @param planeta Planeta a validar
     * @return Mensaje de error o null si es válido
     */
    fun getPlanetaErrorMessage(planeta: String): String? {
        return when {
            planeta.isBlank() -> "Debe seleccionar un planeta"
            else -> null
        }
    }

    /**
     * Obtiene el mensaje de error para el campo nivel de urgencia
     * @param nivelUrgencia Nivel de urgencia a validar
     * @return Mensaje de error o null si es válido
     */
    fun getNivelUrgenciaErrorMessage(nivelUrgencia: String): String? {
        return when {
            nivelUrgencia.isBlank() -> "Debe seleccionar un nivel de urgencia"
            else -> null
        }
    }

    // ========================================
    // FUNCIONES DE COMPATIBILIDAD (para no romper código existente)
    // ========================================

    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    fun getTituloErrorMessage(titulo: String): String? = getNombreMisionErrorMessage(titulo)

    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    fun getDescripcionErrorMessage(descripcion: String): String? = getObjetivoErrorMessage(descripcion)

    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    fun getFechaLimiteErrorMessage(fechaLimiteMillis: Long?): String? = getFechaLanzamientoErrorMessage(fechaLimiteMillis)

    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    fun getCategoriaErrorMessage(categoria: String): String? = getPlanetaErrorMessage(categoria)

    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    fun getPrioridadErrorMessage(prioridad: String): String? = getNivelUrgenciaErrorMessage(prioridad)
}