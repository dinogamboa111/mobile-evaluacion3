// AppUtils.kt
package duoc.desarrollomobile.sitioejemplo.utils

import duoc.desarrollomobile.sitioejemplo.R

fun getPlanetaImageResource(nombrePlaneta: String): Int {
    return when (nombrePlaneta.uppercase()) {
        "MERCURIO" -> R.drawable.mercurio_image
        "VENUS" -> R.drawable.venus_image
        "TIERRA" -> R.drawable.tierra_image
        "MARTE" -> R.drawable.marte_image
        "JÚPITER" -> R.drawable.jupiter_image
        "SATURNO" -> R.drawable.saturno_image
        "URANO" -> R.drawable.urano_image
        "NEPTUNO" -> R.drawable.neptuno_image
        "LUNA" -> R.drawable.luna_image
        else -> R.drawable.sistema_solar_image // Recurso por defecto
    }
}