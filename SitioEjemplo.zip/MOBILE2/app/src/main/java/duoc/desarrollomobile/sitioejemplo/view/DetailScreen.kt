package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.model.NivelUrgencia
import duoc.desarrollomobile.sitioejemplo.model.PlanetaCategoria
import duoc.desarrollomobile.sitioejemplo.ui.components.AppTopBarWithBack
import duoc.desarrollomobile.sitioejemplo.ui.theme.AppThemeExtensions
import duoc.desarrollomobile.sitioejemplo.utils.ShareHelper
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    misionId: Int,
    viewModel: MisionViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mision by remember { mutableStateOf<Mision?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showToggleDialog by remember { mutableStateOf(false) }

    // Cargar misión al inicio
    LaunchedEffect(misionId) {
        mision = viewModel.getMisionById(misionId)
    }

    val backgroundBrush = AppThemeExtensions.deepSpaceBrush

    if (showDeleteDialog && mision != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            icon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Abortar misión") },
            text = { Text("¿Deseas eliminar \"${mision?.nombreMision}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            mision?.let { viewModel.deleteMision(it) }
                            showDeleteDialog = false
                            snackbarHostState.showSnackbar("🗑️ Misión eliminada")
                            kotlinx.coroutines.delay(500)
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancelar") }
            }
        )
    }

    if (showToggleDialog && mision != null) {
        val mis = mision!!
        AlertDialog(
            onDismissRequest = { showToggleDialog = false },
            icon = { Icon(if (mis.completada) Icons.Default.Refresh else Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(if (mis.completada) "Reactivar misión" else "Completar misión") },
            text = { Text("¿Deseas marcar \"${mis.nombreMision}\" como ${if (mis.completada) "en curso" else "completada"}?") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.toggleCompletada(mis) // ← cambiar mis.id por mis
                            mision = viewModel.getMisionById(misionId)
                            showToggleDialog = false
                            val msg = if (!mis.completada) "✅ Misión completada" else "🔄 Misión reactivada"
                            snackbarHostState.showSnackbar(msg)
                        }

                    }
                ) { Text("Confirmar") }
            },
            dismissButton = {
                TextButton(onClick = { showToggleDialog = false }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            AppTopBarWithBack(
                title = "📡 Detalle de Misión",
                onBackClick = onNavigateBack,
                actions = {
                    mision?.let { mis ->
                        IconButton(
                            onClick = {
                                scope.launch {
                                    viewModel.toggleFavorita(mis)
                                    mision = viewModel.getMisionById(misionId)
                                    val msg = if (!mis.isFavorita) "⭐ Favorita" else "Quitar favorita"
                                    snackbarHostState.showSnackbar(msg)
                                }
                            }
                        ) {
                            Icon(
                                if (mis.isFavorita) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = if (mis.isFavorita) Color(0xFFFFB300) else Color.White
                            )
                        }
                    }
                    IconButton(onClick = { mision?.let { ShareHelper.compartirMision(context, it) } }) {
                        Icon(Icons.Default.Share, contentDescription = "Compartir")
                    }
                }
            )
        }
    ) { paddingValues ->
        if (mision == null) {
            Box(
                Modifier.fillMaxSize().padding(paddingValues).background(backgroundBrush),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        } else {
            val mis = mision!!
            val nivelUrgencia = NivelUrgencia.fromString(mis.nivelUrgencia)
            val planeta = PlanetaCategoria.fromString(mis.planeta)

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(backgroundBrush)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Cards de estado, favorita, nombre, objetivo, planeta, urgencia, fecha/hora, notificación y botones
                if (mis.completada) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.width(8.dp))
                            Text("✅ Misión Completada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
                if (mis.isFavorita && !mis.completada) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFB300).copy(alpha = 0.2f)), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, null, tint = Color(0xFFFFB300))
                            Spacer(Modifier.width(8.dp))
                            Text("⭐ Misión Destacada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
                // Aquí puedes agregar las demás Cards: nombre, objetivo, planeta, urgencia, fecha/hora, notificación, botones…
            }
        }
    }
}
