package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.model.PlanetaCategoria
import duoc.desarrollomobile.sitioejemplo.model.NivelUrgencia
import duoc.desarrollomobile.sitioejemplo.ui.components.AppTopBarWithBack
import duoc.desarrollomobile.sitioejemplo.ui.theme.AppThemeExtensions
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Pantalla de formulario para crear una nueva misión espacial
 * Aplica el color de fondo espacial y personaliza los TextField.
 *
 * @param viewModel ViewModel que maneja el estado y la lógica
 * @param onNavigateBack Callback para volver atrás
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormScreen(
    viewModel: MisionViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    var expandedPlaneta by remember { mutableStateOf(false) }
    var expandedUrgencia by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // OBTENER EL BRUSH GLOBAL
    val backgroundBrush = AppThemeExtensions.deepSpaceBrush

    // DEFINICIÓN DEL SHAPE REDONDO (usaremos 12.dp)
    val RoundedShape = RoundedCornerShape(12.dp)

    // Efecto para manejar el guardado exitoso
    LaunchedEffect(uiState.guardadoExitoso) {
        if (uiState.guardadoExitoso) {
            snackbarHostState.showSnackbar(
                message = "🚀 Misión creada exitosamente",
                duration = SnackbarDuration.Short
            )
            kotlinx.coroutines.delay(500)
            viewModel.resetForm()
            onNavigateBack()
        }
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = MaterialTheme.colorScheme.inverseSurface,
                    contentColor = MaterialTheme.colorScheme.inverseOnSurface,
                    actionColor = MaterialTheme.colorScheme.primary
                )
            }
        },
        topBar = {
            AppTopBarWithBack(
                title = "🛸 Nueva Misión",
                onBackClick = onNavigateBack
            )
        }
    ) { paddingValues ->

        // --- COLORES INDIVIDUALES REQUERIDOS ---
        // Definimos las variables de color primitivas para pasarlas a ExposedDropdownMenuDefaults
        val containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        val focusedColor = MaterialTheme.colorScheme.primary
        val unfocusedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
        val unfocusedBorder = MaterialTheme.colorScheme.outlineVariant
        val textColor = MaterialTheme.colorScheme.onSurface

        val textFieldColors = OutlinedTextFieldDefaults.colors(
            // Fondo
            focusedContainerColor = containerColor,
            unfocusedContainerColor = containerColor,
            disabledContainerColor = containerColor.copy(alpha = 0.5f),

            // Texto e iconos
            focusedTextColor = textColor,
            unfocusedTextColor = textColor,
            focusedLeadingIconColor = focusedColor,
            unfocusedLeadingIconColor = unfocusedIconColor,

            // Borde
            focusedBorderColor = focusedColor,
            unfocusedBorderColor = unfocusedBorder,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(backgroundBrush)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Campo de nombre de misión
            OutlinedTextField(
                value = uiState.nombreMision,
                onValueChange = { viewModel.onNombreMisionChange(it) },
                label = { Text("Nombre de la Misión *") },
                placeholder = { Text("Ej: Calibrar Satélite Orbital") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null)
                },
                isError = uiState.nombreMisionError != null,
                supportingText = {
                    uiState.nombreMisionError?.let { Text(it) }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedShape,
                colors = textFieldColors
            )

            // Campo de objetivo con contador de caracteres
            OutlinedTextField(
                value = uiState.objetivo,
                onValueChange = { viewModel.onObjetivoChange(it) },
                label = { Text("Objetivo de la Misión *") },
                placeholder = { Text("Describe el objetivo a cumplir") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Flag, contentDescription = null)
                },
                isError = uiState.objetivoError != null,
                supportingText = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(uiState.objetivoError ?: "")
                        Text("${uiState.objetivo.length}/200")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
                shape = RoundedShape,
                colors = textFieldColors
            )

            // Dropdown de planeta
            ExposedDropdownMenuBox(
                expanded = expandedPlaneta,
                onExpandedChange = { expandedPlaneta = !expandedPlaneta }
            ) {
                OutlinedTextField(
                    value = if (uiState.planeta.isNotEmpty()) {
                        val planetaEnum = PlanetaCategoria.fromString(uiState.planeta)
                        "${planetaEnum.emoji} ${planetaEnum.displayName}"
                    } else {
                        ""
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Planeta de Operación *") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Public, contentDescription = null)
                    },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPlaneta)
                    },
                    isError = uiState.planetaError != null,
                    supportingText = {
                        uiState.planetaError?.let { Text(it) }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(),
                    shape = RoundedShape,

                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                        focusedContainerColor = containerColor,
                        unfocusedContainerColor = containerColor,
                        focusedTextColor = textColor,
                        unfocusedTextColor = textColor,
                        focusedLeadingIconColor = focusedColor,
                        unfocusedLeadingIconColor = unfocusedIconColor,
                        focusedBorderColor = focusedColor,
                        unfocusedBorderColor = unfocusedBorder,
                        focusedTrailingIconColor = focusedColor,
                        unfocusedTrailingIconColor = unfocusedIconColor
                    )
                )

                ExposedDropdownMenu(
                    expanded = expandedPlaneta,
                    onDismissRequest = { expandedPlaneta = false }
                ) {
                    PlanetaCategoria.entries.forEach { planeta ->
                        DropdownMenuItem(
                            text = { Text("${planeta.emoji} ${planeta.displayName}") },
                            onClick = {
                                viewModel.onPlanetaChange(planeta.name)
                                expandedPlaneta = false
                            },
                            leadingIcon = {
                                Text(planeta.emoji, style = MaterialTheme.typography.titleMedium)
                            }
                        )
                    }
                }
            }

            // Selector de fecha de lanzamiento
            OutlinedTextField(
                value = if (uiState.fechaLanzamiento != null) {
                    formatFecha(uiState.fechaLanzamiento!!)
                } else {
                    ""
                },
                onValueChange = {},
                readOnly = true,
                label = { Text("Fecha de Lanzamiento *") },
                placeholder = { Text("Selecciona la fecha") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null)
                },
                trailingIcon = {
                    IconButton(onClick = { showDatePicker = true }) {
                        Icon(imageVector = Icons.Default.EditCalendar, contentDescription = "Seleccionar fecha")
                    }
                },
                isError = uiState.fechaLanzamientoError != null,
                supportingText = {
                    uiState.fechaLanzamientoError?.let { Text(it) }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedShape,
                colors = textFieldColors
            )

            // Campo de hora de lanzamiento
            OutlinedTextField(
                value = uiState.horaLanzamiento,
                onValueChange = { viewModel.onHoraChange(it) },
                label = { Text("Hora de Lanzamiento (HH:mm) *") },
                placeholder = { Text("Ej: 14:30") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null)
                },
                trailingIcon = {
                    IconButton(onClick = { showTimePicker = true }) {
                        Icon(imageVector = Icons.Default.AccessTime, contentDescription = "Seleccionar hora")
                    }
                },
                isError = uiState.horaError != null,
                supportingText = {
                    uiState.horaError?.let { Text(it) }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedShape,
                colors = textFieldColors
            )

            // Dropdown de nivel de urgencia
            ExposedDropdownMenuBox(
                expanded = expandedUrgencia,
                onExpandedChange = { expandedUrgencia = !expandedUrgencia }
            ) {
                OutlinedTextField(
                    value = if (uiState.nivelUrgencia.isNotEmpty()) {
                        val urgenciaEnum = NivelUrgencia.fromString(uiState.nivelUrgencia)
                        "${urgenciaEnum.emoji} ${urgenciaEnum.displayName}"
                    } else {
                        ""
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Nivel de Urgencia *") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null)
                    },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedUrgencia)
                    },
                    isError = uiState.nivelUrgenciaError != null,
                    supportingText = {
                        uiState.nivelUrgenciaError?.let { Text(it) }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(),
                    shape = RoundedShape,

                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                        focusedContainerColor = containerColor,
                        unfocusedContainerColor = containerColor,
                        focusedTextColor = textColor,
                        unfocusedTextColor = textColor,
                        focusedLeadingIconColor = focusedColor,
                        unfocusedLeadingIconColor = unfocusedIconColor,
                        focusedBorderColor = focusedColor,
                        unfocusedBorderColor = unfocusedBorder,
                        focusedTrailingIconColor = focusedColor,
                        unfocusedTrailingIconColor = unfocusedIconColor
                    )
                )

                ExposedDropdownMenu(
                    expanded = expandedUrgencia,
                    onDismissRequest = { expandedUrgencia = false }
                ) {
                    NivelUrgencia.entries.forEach { urgencia ->
                        DropdownMenuItem(
                            text = { Text(urgencia.displayName) },
                            onClick = {
                                viewModel.onNivelUrgenciaChange(urgencia.name)
                                expandedUrgencia = false
                            },
                            leadingIcon = {
                                Text(urgencia.emoji, style = MaterialTheme.typography.titleMedium)
                            }
                        )
                    }
                }
            }

            // Switch de notificaciones
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedShape
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(
                                text = "Alerta de lanzamiento",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Recibir notificación a la hora indicada",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = uiState.notificacionActiva,
                        onCheckedChange = { viewModel.toggleNotificacion() }
                    )
                }
            }

            // Switch de misión favorita
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedShape
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (uiState.isFavorita) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Column {
                            Text(
                                text = "Misión destacada",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Marcar como misión prioritaria",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = uiState.isFavorita,
                        onCheckedChange = { viewModel.toggleFavorita() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Botón de guardar
            Button(
                onClick = { viewModel.onGuardarClick() },
                modifier = Modifier.fillMaxWidth()
                    .height(56.dp),
                enabled = !uiState.isLoading,
                shape = RoundedShape
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Iniciar Misión")
                }
            }
        }
    }

    // DatePicker Dialog (código sin cambios)
    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = uiState.fechaLanzamiento ?: System.currentTimeMillis()
        )

        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { utcMillis ->
                            val calendar = Calendar.getInstance()
                            val timeZone = TimeZone.getDefault()
                            val offset = timeZone.getOffset(utcMillis)
                            val localMillis = utcMillis + offset

                            calendar.timeInMillis = localMillis
                            calendar.set(Calendar.HOUR_OF_DAY, 12)
                            calendar.set(Calendar.MINUTE, 0)
                            calendar.set(Calendar.SECOND, 0)
                            calendar.set(Calendar.MILLISECOND, 0)

                            viewModel.onFechaLanzamientoChange(calendar.timeInMillis)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // TimePicker Dialog con selector visual (código sin cambios)
    if (showTimePicker) {
        val currentTime = try {
            if (uiState.horaLanzamiento.isNotEmpty()) {
                val parts = uiState.horaLanzamiento.split(":")
                Pair(parts[0].toInt(), parts[1].toInt())
            } else {
                val calendar = Calendar.getInstance()
                Pair(calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE))
            }
        } catch (e: Exception) {
            val calendar = Calendar.getInstance()
            Pair(calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE))
        }

        val timePickerState = rememberTimePickerState(
            initialHour = currentTime.first,
            initialMinute = currentTime.second,
            is24Hour = true
        )

        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val hora = String.format("%02d:%02d", timePickerState.hour, timePickerState.minute)
                        viewModel.onHoraChange(hora)
                        showTimePicker = false
                    }
                ) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Cancelar")
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Seleccionar Hora de Lanzamiento",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    TimePicker(
                        state = timePickerState,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        )
    }
}