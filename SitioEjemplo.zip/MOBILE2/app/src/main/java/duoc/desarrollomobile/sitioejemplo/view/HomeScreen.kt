package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.R
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel


@Composable
fun HomeScreen(
    viewModel: MisionViewModel,
    onNavigateToForm: () -> Unit,
    onNavigateToDetail: (Int) -> Unit,
    onNavigateToPlanetas: () -> Unit,
    onNavigateToCentroControl: () -> Unit,
    onNavigateToList: (FiltroMision) -> Unit
) {
    val misionesPendientes by viewModel.misionesPendientes.collectAsState(initial = emptyList())
    val misionesCompletadas by viewModel.misionesCompletadas.collectAsState(initial = emptyList())
    val misionesFavoritas by viewModel.misionesFavoritas.collectAsState(initial = emptyList())

    // Carga de la imagen de fondo
    val backgroundPainter = painterResource(id = R.drawable.ic_fondo_galaxia)

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Fondo de imagen
        Image(
            painter = backgroundPainter,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize()
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(Color.Black.copy(alpha = 0.3f))
        )

        // Contenido principal (Logo y Menú)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
         //logo

            Spacer(modifier = Modifier.weight(0.3f))

            // Logo grande (Contiene el texto "Galaxy Tasks")
            Image(
                painter = painterResource(id = R.drawable.logo_image),
                contentDescription = "Galaxy Tasks Logo",
                modifier = Modifier
                    .size(320.dp)
                    .padding(vertical = 8.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // opciones de navegacion

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                MenuButton(
                    icon = Icons.Default.RocketLaunch,
                    text = "Misiones en Curso (${misionesPendientes.size})",
                    onClick = { onNavigateToList(FiltroMision.PENDIENTES) }
                )

                MenuButton(
                    icon = Icons.Default.Star,
                    text = "Misiones Favoritas (${misionesFavoritas.size})",
                    onClick = { onNavigateToList(FiltroMision.FAVORITAS) }
                )

                MenuButton(
                    icon = Icons.Default.CheckCircle,
                    text = "Misiones Exitosas (${misionesCompletadas.size})",
                    onClick = { onNavigateToList(FiltroMision.COMPLETADAS) }
                )

                MenuButton(
                    icon = Icons.Default.BarChart,
                    text = "Centro de Control",
                    onClick = onNavigateToCentroControl
                )

                MenuButton(
                    icon = Icons.Default.Public,
                    text = "Explorar Planetas",
                    onClick = onNavigateToPlanetas
                )
            }

            Spacer(modifier = Modifier.weight(0.5f))
        }

        //boton + arriba a la derecha

        FloatingActionButton(
            onClick = onNavigateToForm,
            containerColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 16.dp, end = 16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Nueva misión", tint = MaterialTheme.colorScheme.onSecondary)
        }
    }
}


// Componente de botón reutilizable
@Composable
fun MenuButton(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth(0.75f)
            .height(60.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(16.dp))
            Text(text, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        }
    }
}