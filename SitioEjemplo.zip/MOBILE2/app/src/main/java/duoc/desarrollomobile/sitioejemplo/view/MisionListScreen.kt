package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.model.NivelUrgencia
import duoc.desarrollomobile.sitioejemplo.ui.theme.AppThemeExtensions
import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class FiltroMision {
    PENDIENTES,
    COMPLETADAS,
    FAVORITAS,
    TODAS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MisionListScreen(
    viewModel: MisionViewModel,
    filtroInicial: FiltroMision,
    onNavigateToDetail: (Int) -> Unit,
    onNavigateBack: () -> Unit
) {
    val misionesPendientes by viewModel.misionesPendientes.collectAsState(initial = emptyList())
    val misionesCompletadas by viewModel.misionesCompletadas.collectAsState(initial = emptyList())
    val misionesFavoritas by viewModel.misionesFavoritas.collectAsState(initial = emptyList())

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var misionToDelete by remember { mutableStateOf<Mision?>(null) }

    val misionesMostradas = when (filtroInicial) {
        FiltroMision.PENDIENTES -> misionesPendientes
        FiltroMision.COMPLETADAS -> misionesCompletadas
        FiltroMision.FAVORITAS -> misionesFavoritas
        FiltroMision.TODAS -> misionesPendientes + misionesCompletadas
    }

    val title = when (filtroInicial) {
        FiltroMision.PENDIENTES -> "Misiones en Curso (${misionesPendientes.size})"
        FiltroMision.COMPLETADAS -> "Misiones Exitosas (${misionesCompletadas.size})"
        FiltroMision.FAVORITAS -> "Misiones Favoritas (${misionesFavoritas.size})"
        FiltroMision.TODAS -> "Todas las Misiones (${misionesMostradas.size})"
    }

    val backgroundBrush = AppThemeExtensions.deepSpaceBrush

    // Dialogos (si se requiere) - puedes implementarlos según tu lógica
    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Eliminar todas las completadas") },
            text = { Text("¿Seguro deseas eliminar todas las misiones completadas?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteAllCompletadas()
                    showDeleteAllDialog = false
                }) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancelar") }
            }
        )
    }

    misionToDelete?.let { mision ->
        AlertDialog(
            onDismissRequest = { misionToDelete = null },
            title = { Text("Eliminar misión") },
            text = { Text("¿Seguro deseas eliminar la misión \"${mision.nombreMision}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteMision(mision)
                    misionToDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { misionToDelete = null }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    if (filtroInicial == FiltroMision.COMPLETADAS && misionesCompletadas.isNotEmpty()) {
                        IconButton(onClick = { showDeleteAllDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar completadas")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )

            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundBrush)
                .padding(paddingValues)
        ) {
            AnimatedVisibility(
                visible = misionesMostradas.isEmpty(),
                enter = fadeIn(animationSpec = tween(300)),
                exit = fadeOut(animationSpec = tween(300))
            ) { EmptyState(filtro = filtroInicial) }

            AnimatedVisibility(
                visible = misionesMostradas.isNotEmpty(),
                enter = fadeIn(animationSpec = tween(300)) +
                        slideInVertically(animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        )),
                exit = fadeOut(animationSpec = tween(300)) +
                        slideOutVertically(animationSpec = tween(300))
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(items = misionesMostradas, key = { it.id }) { mision ->
                        MisionItem(
                            mision = mision,
                            onToggleCompletada = { viewModel.toggleCompletada(mision) },
                            onToggleFavorita = { viewModel.toggleFavorita(mision) },
                            onDelete = { misionToDelete = mision },
                            onClick = { onNavigateToDetail(mision.id) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MisionItem(
    mision: Mision,
    onToggleCompletada: () -> Unit,
    onToggleFavorita: () -> Unit,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    val nivelUrgencia = NivelUrgencia.fromString(mision.nivelUrgencia)
    val colorUrgencia = Color(nivelUrgencia.colorValue)
    val isDark = isSystemInDarkTheme()

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (mision.completada)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            else
                MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(colorUrgencia)
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = mision.completada,
                    onCheckedChange = { onToggleCompletada() }
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = mision.nombreMision,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textDecoration = if (mision.completada) TextDecoration.LineThrough else null,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (mision.isFavorita) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Favorita",
                                tint = Color(0xFFFFB300),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = mision.objetivo,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = {},
                            label = { Text(text = mision.planeta, style = MaterialTheme.typography.labelSmall) },
                            leadingIcon = { Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )

                        AssistChip(
                            onClick = {},
                            label = { Text(text = formatFecha(mision.fechaLanzamiento), style = MaterialTheme.typography.labelSmall) },
                            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )

                        AssistChip(
                            onClick = {},
                            label = { Text(text = "${nivelUrgencia.emoji}", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onToggleFavorita) {
                        Icon(
                            imageVector = if (mision.isFavorita) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = if (mision.isFavorita) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(filtro: FiltroMision) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(
                imageVector = when (filtro) {
                    FiltroMision.PENDIENTES -> Icons.Default.RocketLaunch
                    FiltroMision.COMPLETADAS -> Icons.Default.CheckCircle
                    FiltroMision.FAVORITAS -> Icons.Default.StarBorder
                    FiltroMision.TODAS -> Icons.Default.Explore
                },
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = when (filtro) {
                    FiltroMision.PENDIENTES -> "No hay misiones en curso"
                    FiltroMision.COMPLETADAS -> "No hay misiones completadas"
                    FiltroMision.FAVORITAS -> "No hay misiones favoritas"
                    FiltroMision.TODAS -> "No hay misiones"
                },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = when (filtro) {
                    FiltroMision.PENDIENTES -> "Crea tu primera misión espacial"
                    FiltroMision.COMPLETADAS -> "Completa algunas misiones"
                    FiltroMision.FAVORITAS -> "Marca misiones con ★ para destacarlas"
                    FiltroMision.TODAS -> "Presiona + para iniciar tu primera misión"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun formatFecha(millis: Long?): String {
    if (millis == null) return ""
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    dateFormat.timeZone = TimeZone.getDefault()
    return dateFormat.format(Date(millis))
}
