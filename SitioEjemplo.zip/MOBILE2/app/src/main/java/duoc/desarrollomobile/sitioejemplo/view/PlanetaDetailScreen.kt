package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.data.Planeta
import duoc.desarrollomobile.sitioejemplo.ui.components.AppTopBarWithBack

import duoc.desarrollomobile.sitioejemplo.ui.theme.AppThemeExtensions

import duoc.desarrollomobile.sitioejemplo.viewmodel.MisionViewModel
import duoc.desarrollomobile.sitioejemplo.viewmodel.PlanetaViewModel
import kotlinx.coroutines.launch

import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import duoc.desarrollomobile.sitioejemplo.R
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.utils.getPlanetaImageResource



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanetaDetailScreen(
    planetaId: Int,
    viewModel: PlanetaViewModel,
    misionViewModel: MisionViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToMision: (Int) -> Unit
) {
    val scope = rememberCoroutineScope()

    // Estados
    var planeta by remember { mutableStateOf<Planeta?>(null) }
    var misionesDelPlaneta by remember { mutableStateOf<List<Mision>>(emptyList()) }

    // Cargar planeta y sus misiones
    LaunchedEffect(planetaId) {
        scope.launch {
            planeta = viewModel.getPlanetaById(planetaId)
            planeta?.let { p ->
                misionViewModel.allMisiones.collect { todasMisiones ->
                    misionesDelPlaneta = todasMisiones.filter {
                        // Asegúrate de que esta comparación sea sensible a mayúsculas/minúsculas o ajústala
                        it.planeta == p.nombre.uppercase()
                    }
                }
            }
        }
    }


    val backgroundBrush = AppThemeExtensions.deepSpaceBrush


    val colorPlaneta = planeta?.let {
        try {
            Color(android.graphics.Color.parseColor(it.colorHex))
        } catch (e: Exception) {
            MaterialTheme.colorScheme.primary
        }
    } ?: MaterialTheme.colorScheme.primary

    Scaffold(
        topBar = {
            AppTopBarWithBack(
                title = "🪐 ${planeta?.nombre ?: "Cargando..."}",
                onBackClick = onNavigateBack
            )
        }
    ) { paddingValues ->
        if (planeta == null) {
            // Loading
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)

                    .background(backgroundBrush),

                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)

                    .background(backgroundBrush)

                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val p = planeta!!

                // Card visual del planeta
                Card(
                    modifier = Modifier.fillMaxWidth(),

                    colors = CardDefaults.cardColors(
                        containerColor = colorPlaneta.copy(alpha = 0.1f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            colorPlaneta.copy(alpha = 0.6f),
                                            colorPlaneta
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {

                            val imageResId = getPlanetaImageResource(p.nombre) // Usa la función importada

                            Image(
                                painter = painterResource(id = imageResId),
                                contentDescription = p.nombre,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                            )

                        }


                        Text(
                            text = p.nombre,
                            style = MaterialTheme.typography.displaySmall,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = Color.White
                        )


                        Text(
                            text = p.tipo,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                    }
                }

                // Descripción
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Descripción",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = p.descripcion ?: "Sin descripción disponible",
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = MaterialTheme.typography.bodyLarge.lineHeight
                        )
                    }
                }

                // Datos técnicos
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Datos Técnicos",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Divider()

                        // Distancia al Sol
                        if (p.distanciaSol > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WbSunny,
                                        contentDescription = null,
                                        tint = Color(0xFFFFA726),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Distancia al Sol",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Text(
                                    text = "${p.distanciaSol.toInt()} millones km",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Divider()

                        // Tipo de planeta
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = when (p.tipo) {
                                        "Rocoso" -> Icons.Default.Terrain
                                        "Gaseoso" -> Icons.Default.Air
                                        "Satélite" -> Icons.Default.NightsStay
                                        else -> Icons.Default.Stars
                                    },
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Tipo",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Text(
                                text = p.tipo,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Misiones asociadas
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Misiones en ${p.nombre}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (misionesDelPlaneta.isEmpty()) {
                            Text(
                                text = "No hay misiones programadas para este planeta",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            Text(
                                text = "${misionesDelPlaneta.size} misión(es) activa(s)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Divider()

                            misionesDelPlaneta.take(5).forEach { mision ->
                                MisionCompactaItem(
                                    mision = mision,
                                    onClick = { onNavigateToMision(mision.id) }
                                )
                                if (mision != misionesDelPlaneta.take(5).last()) Divider()
                            }

                            if (misionesDelPlaneta.size > 5) {
                                Text(
                                    text = "...y ${misionesDelPlaneta.size - 5} más",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MisionCompactaItem(
    mision: Mision,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() } // Corregido clickable
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(
                    if (mision.completada)
                        MaterialTheme.colorScheme.secondary
                    else
                        MaterialTheme.colorScheme.primary
                )
        )

        Column(modifier = Modifier.weight(1f)) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = mision.nombreMision,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (mision.isFavorita) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Favorita",
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                text = formatFecha(mision.fechaLanzamiento),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Icon(
            imageVector = Icons.Filled.ArrowForward, // No está deprecated
            contentDescription = "Ver detalle",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
    }
}