package duoc.desarrollomobile.sitioejemplo.view

import androidx.compose.foundation.Image // <-- AGREGADO
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import duoc.desarrollomobile.sitioejemplo.data.Planeta
import duoc.desarrollomobile.sitioejemplo.ui.components.AppTopBarWithBack
import duoc.desarrollomobile.sitioejemplo.ui.theme.AppThemeExtensions

import duoc.desarrollomobile.sitioejemplo.viewmodel.PlanetaViewModel

import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import duoc.desarrollomobile.sitioejemplo.R
import duoc.desarrollomobile.sitioejemplo.utils.getPlanetaImageResource

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanetasScreen(
    viewModel: PlanetaViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToPlanetaDetail: (Int) -> Unit
) {
    val planetas by viewModel.allPlanetas.collectAsState(initial = emptyList())

    val backgroundBrush = AppThemeExtensions.deepSpaceBrush


    Scaffold(
        topBar = {
            AppTopBarWithBack(
                title = "🪐 Explorar Sistema Solar",
                onBackClick = onNavigateBack
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            // [INICIO AGREGADO]
            .background(backgroundBrush)
            // [FIN AGREGADO]
        ) {

            if (planetas.isEmpty()) {
                // Loading
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(planetas, key = { it.id }) { planeta ->
                        PlanetaItem(
                            planeta = planeta,
                            onClick = { onNavigateToPlanetaDetail(planeta.id) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanetaItem(
    planeta: Planeta,
    onClick: () -> Unit
) {
    val colorPlaneta = try {
        Color(android.graphics.Color.parseColor(planeta.colorHex))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Color lateral
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(colorPlaneta, colorPlaneta.copy(alpha = 0.6f))
                        )
                    )
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(colorPlaneta.copy(alpha = 0.8f), colorPlaneta)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {

                    val imageResId = getPlanetaImageResource(planeta.nombre)

                    Image(
                        painter = painterResource(id = imageResId),
                        contentDescription = planeta.nombre,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                    )

                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = planeta.nombre,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = planeta.tipo,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Icon(
                    imageVector = Icons.Filled.ArrowForward,
                    contentDescription = "Ver detalle",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}