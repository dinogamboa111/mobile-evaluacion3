package duoc.desarrollomobile.sitioejemplo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import duoc.desarrollomobile.sitioejemplo.data.Mision
import duoc.desarrollomobile.sitioejemplo.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date

data class MisionUiState(
    val nombreMision: String = "",
    val objetivo: String = "",
    val planeta: String = "",
    val fechaLanzamiento: Long? = null,
    val horaLanzamiento: String = "",
    val nivelUrgencia: String = "",
    val notificacionActiva: Boolean = true,
    val isFavorita: Boolean = false,
    val nombreMisionError: String? = null,
    val objetivoError: String? = null,
    val planetaError: String? = null,
    val fechaLanzamientoError: String? = null,
    val horaError: String? = null,
    val nivelUrgenciaError: String? = null,
    val isLoading: Boolean = false,
    val guardadoExitoso: Boolean = false,
    val listaPlanetas: List<String> = emptyList(),
    val listaNivelesUrgencia: List<String> = NivelUrgencia.getAllDisplayNames(),
    val apiError: String? = null
)

class MisionViewModel(
    private val repository: MisionRepository,
    private val planetaRepository: PlanetaRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MisionUiState(isLoading = true))
    val uiState: StateFlow<MisionUiState> = _uiState.asStateFlow()

    val allMisiones = repository.allMisiones
    val misionesPendientes = repository.misionesPendientes
    val misionesCompletadas = repository.misionesCompletadas
    val misionesFavoritas = repository.misionesFavoritas
    val misionesFavoritasPendientes = repository.misionesFavoritasPendientes

    private val _estadisticas = MutableStateFlow(EstadisticasMision(0, 0, 0, 0))
    val estadisticas: StateFlow<EstadisticasMision> = _estadisticas.asStateFlow()

    init {
        // Cargar planetas
        viewModelScope.launch {
            try {
                val planetas = planetaRepository.allPlanetas.firstOrNull() ?: emptyList()
                _uiState.value = _uiState.value.copy(
                    listaPlanetas = planetas.map { it.nombre }
                )
            } catch (_: Exception) {}
        }

        // Sincronizar misiones desde API al iniciar la app
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, apiError = null)
            try {
                repository.syncMisionesDesdeApi() // descarga y guarda en Room
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(apiError = "Error al cargar misiones desde API")
                e.printStackTrace()
            } finally {
                _uiState.value = _uiState.value.copy(isLoading = false)
            }
            refreshEstadisticas()
        }
    }

    private fun refreshEstadisticas() {
        viewModelScope.launch {
            val dto = repository.getEstadisticas()
            _estadisticas.value = EstadisticasMision(
                total = dto.totalMisiones,
                pendientes = dto.pendientes,
                completadas = dto.completadas,
                favoritas = dto.favoritas
            )
        }
    }

    // --- Métodos para FormScreen ---
    fun onNombreMisionChange(value: String) {
        _uiState.value = _uiState.value.copy(nombreMision = value)
    }

    fun onObjetivoChange(value: String) {
        _uiState.value = _uiState.value.copy(objetivo = value)
    }

    fun onPlanetaChange(value: String) {
        _uiState.value = _uiState.value.copy(planeta = value)
    }

    fun onNivelUrgenciaChange(value: String) {
        _uiState.value = _uiState.value.copy(nivelUrgencia = value)
    }

    fun onFechaLanzamientoChange(value: Long) {
        _uiState.value = _uiState.value.copy(fechaLanzamiento = value)
    }

    fun onHoraChange(value: String) {
        _uiState.value = _uiState.value.copy(horaLanzamiento = value)
    }

    fun toggleNotificacion() {
        _uiState.value = _uiState.value.copy(notificacionActiva = !_uiState.value.notificacionActiva)
    }

    fun toggleFavorita() {
        _uiState.value = _uiState.value.copy(isFavorita = !_uiState.value.isFavorita)
    }

    fun resetForm() {
        _uiState.value = MisionUiState()
    }

    // --- Guardar misión tanto en API como Room ---
    fun onGuardarClick() {
        viewModelScope.launch {
            val nombreError = if (_uiState.value.nombreMision.isBlank()) "Requerido" else null
            val objetivoError = if (_uiState.value.objetivo.isBlank()) "Requerido" else null
            val planetaError = if (_uiState.value.planeta.isBlank()) "Requerido" else null
            val fechaError = if (_uiState.value.fechaLanzamiento == null) "Requerido" else null
            val horaError = if (_uiState.value.horaLanzamiento.isBlank()) "Requerido" else null
            val urgenciaError = if (_uiState.value.nivelUrgencia.isBlank()) "Requerido" else null

            _uiState.value = _uiState.value.copy(
                nombreMisionError = nombreError,
                objetivoError = objetivoError,
                planetaError = planetaError,
                fechaLanzamientoError = fechaError,
                horaError = horaError,
                nivelUrgenciaError = urgenciaError,
                guardadoExitoso = false,
                apiError = null
            )

            if (listOf(nombreError, objetivoError, planetaError, fechaError, horaError, urgenciaError).all { it == null }) {
                val nuevaMision = Mision(
                    id = 0,
                    nombreMision = _uiState.value.nombreMision,
                    objetivo = _uiState.value.objetivo,
                    planeta = _uiState.value.planeta,
                    fechaLanzamiento = _uiState.value.fechaLanzamiento!!,
                    horaLanzamiento = _uiState.value.horaLanzamiento,
                    nivelUrgencia = _uiState.value.nivelUrgencia,
                    notificacionActiva = _uiState.value.notificacionActiva,
                    isFavorita = _uiState.value.isFavorita,
                    completada = false
                )

                _uiState.value = _uiState.value.copy(isLoading = true)

                try {
                    // Crear en API y actualizar Room
                    val creada = repository.crearMisionEnApi(nuevaMision)
                    if (creada != null) {
                        _uiState.value = _uiState.value.copy(guardadoExitoso = true)
                    } else {
                        _uiState.value = _uiState.value.copy(apiError = "Error al guardar misión en API")
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    _uiState.value = _uiState.value.copy(apiError = "Error al guardar misión")
                } finally {
                    _uiState.value = _uiState.value.copy(isLoading = false)
                }
            }
        }
    }

    // --- Métodos para DetailScreen ---
    fun toggleCompletada(mision: Mision) {
        viewModelScope.launch {
            val actualizada = repository.toggleCompletadaMision(mision)
            if (actualizada != null) {
                refreshEstadisticas() // Actualiza estadísticas
            }

        }
    }


    fun toggleFavorita(mision: Mision) {
        viewModelScope.launch {
            repository.updateMision(mision.copy(isFavorita = !mision.isFavorita))
        }
    }

    fun deleteMision(mision: Mision) {
        viewModelScope.launch {
            repository.deleteMision(mision)
        }
    }


    fun insertMision(mision: Mision) {
        viewModelScope.launch { repository.insertMision(mision) }
    }

    fun deleteAllCompletadas() {
        viewModelScope.launch { repository.deleteAllCompletadas() }
    }

    fun getProximasMisiones(limite: Int = 5) = repository.getProximasMisiones(limite)

    suspend fun getMisionById(id: Int): Mision? {
        return allMisiones.firstOrNull()?.find { it.id == id }
    }
}
