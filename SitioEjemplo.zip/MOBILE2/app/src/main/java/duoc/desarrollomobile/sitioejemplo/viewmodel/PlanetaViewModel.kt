package duoc.desarrollomobile.sitioejemplo.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import duoc.desarrollomobile.sitioejemplo.data.Planeta
import duoc.desarrollomobile.sitioejemplo.model.PlanetaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow

data class PlanetaUiState(
    val planetaSeleccionado: Planeta? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

class PlanetaViewModel(
    private val repository: PlanetaRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlanetaUiState())
    val uiState: StateFlow<PlanetaUiState> = _uiState.asStateFlow()

    // Flow directo desde Room
    val allPlanetas: Flow<List<Planeta>> = repository.allPlanetas

    init {
        Log.d("PlanetaViewModel", "🎬 ViewModel inicializado")
        // Precargar planetas al iniciar
        cargarPlanetasIniciales()
    }

    /**
     * Carga los planetas desde la API si la BD está vacía
     */
    private fun cargarPlanetasIniciales() {
        Log.d("PlanetaViewModel", "🔄 Iniciando carga de planetas...")
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                repository.precargarPlanetasIniciales()
                _uiState.value = _uiState.value.copy(isLoading = false)
                Log.d("PlanetaViewModel", "✅ Carga completada")
            } catch (e: Exception) {
                Log.e("PlanetaViewModel", "❌ Error: ${e.message}", e)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error al cargar planetas: ${e.message}"
                )
            }
        }
    }

    /**
     * Fuerza la recarga desde la API (útil para refresh)
     */
    fun recargarPlanetas() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                repository.recargarPlanetasDesdeApi()
                _uiState.value = _uiState.value.copy(isLoading = false, error = null)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error al recargar: ${e.message}"
                )
            }
        }
    }

    fun cargarPlaneta(planetaId: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val planeta = repository.getPlanetaById(planetaId)
                _uiState.value = _uiState.value.copy(
                    planetaSeleccionado = planeta,
                    isLoading = false,
                    error = if (planeta == null) "Planeta no encontrado" else null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error al cargar el planeta: ${e.message}"
                )
            }
        }
    }

    fun limpiarPlanetaSeleccionado() {
        _uiState.value = _uiState.value.copy(planetaSeleccionado = null, error = null)
    }

    fun limpiarError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    suspend fun getPlanetaById(id: Int): Planeta? {
        return repository.getPlanetaById(id)
    }
}